---
name: "next-best-practices"
description: "Next.js best practices - file conventions, RSC boundaries, data patterns, async APIs, metadata, error handling, route handlers, image/font optimization, bundling"
slug: "next-best-practices"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "038954e07bfc313e97fa5f6ff7caf87226e4a782"
      path: "skills/next-best-practices"
      repo: "vercel-labs/next-skills"
      trackingRef: "main"
      url: "https://github.com/vercel-labs/next-skills"
key: "vercel-labs/next-skills/next-best-practices"
---

