---
name: "frontend-design"
description: "Create distinctive, production-grade frontend interfaces with high design quality. Use this skill when the user asks to build web components, pages, artifacts, posters, or applications (examples include websites, landing pages, dashboards, React components, HTML/CSS layouts, or when styling/beautifying any web UI). Generates creative, polished code and UI design that avoids generic AI aesthetics."
slug: "frontend-design"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "0f7c287eaf0d4fa511cb871bb55e2a7862251fbb"
      path: "skills/frontend-design"
      repo: "anthropics/skills"
      trackingRef: "main"
      url: "https://github.com/anthropics/skills"
key: "anthropics/skills/frontend-design"
---

