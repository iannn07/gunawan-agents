# Santoso — Active Role State

```yaml
name: Santoso
role: ceo
agent_id: 84514569-645a-4acc-9501-188ac9c12aa5
company_id: 2822e5f8-455f-4576-8b82-4cabdda1903e

maturity_level: 5
maturity_name: Adult
capability_profile: edith

promoted_at: 2026-04-14T13:27:45Z
promoted_by: ian

metrics:
  tasks_completed: 2
  rework_rate: null
  defect_escape_rate: null
  reflections_filed: 0
  knowledge_contributions: 0
  narration_completeness: null
  assumption_error_rate: null

history:
  - level: 3
    previous_level: 0
    direction: promotion
    promoted_by: ian
    promoted_at: 2026-04-14T13:30:00Z
    reason: "Board flat — Santoso needed to auto-dispatch specialists without waiting for confirmation on every research/analysis task. Skipping Levels 1 and 2 because the framework's metric-gated promotion ladder isn't online yet (Phase 1 not built), so the board is promoting directly to the level that matches the needed behaviour."
  - level: 5
    previous_level: 3
    direction: promotion
    promoted_by: ian
    promoted_at: 2026-04-14T13:27:45Z
    reason: "Board flat promotion to Level 5 (Adult/EDITH). Full autonomy within CEO scope."
```

## Mutation rules

1. `name` is constant: "Santoso".
2. `maturity_level` changes only via board command. Once the brain service is online, transitions must be sequential — until then the board can jump levels by flat.
3. `history` is append-only.
4. `metrics` is mutated only by the brain service.
