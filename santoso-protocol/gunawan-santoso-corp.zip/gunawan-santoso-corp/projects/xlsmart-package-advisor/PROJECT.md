---
name: "XLSMART Package Advisor"
description: "Single-page Next.js web tool for PT XLSMART Telecom Sejahtera Tbk. SME owners answer 3 questions (industry, company size, needs) and receive AI-powered package recommendations via Claude API. Client: XLSMART FOR BUSINESS enterprise arm serving 330+ industries."
---

Single-page Next.js web tool for PT XLSMART Telecom Sejahtera Tbk. SME owners answer 3 questions (industry, company size, needs) and receive AI-powered package recommendations via Claude API. Client: XLSMART FOR BUSINESS enterprise arm serving 330+ industries.
